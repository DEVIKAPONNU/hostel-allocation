<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Student Profile</title>
<link rel="stylesheet" href="main.css" />
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body class="image-login">
  <?php
  require('db.php');

  $ad=$_SESSION['admission_no'];
  $res=$_SESSION['reservation_id'];
  $verified=$_SESSION['verified'];
  if($res==4){
    $query = "SELECT * FROM `sc_st` WHERE admission_no='$ad';";
    $result = mysqli_query($con,$query) or die(mysql_error());
      if($result){

            while($r=$result->fetch_object()){
              $rank_point=$r->rank_point;
              $rank=$r->rank;
            }
           }
         }
  else{
    $query = "SELECT * FROM `general` WHERE admission_no='$ad';";
    $result = mysqli_query($con,$query) or die(mysql_error());
      if($result){
            while($r=$result->fetch_object()){
              $rank_point=$r->rank_point;
              $rank=$r->rank;
            }

           }
  }
   ?>

<div class="wrapper">
<div id="formContent" >
	<div class="card card-4" >
					<div class="card-body" >
<h2><b>PROFILE</b></h2><br/>

<table border="1px" height="200" width="600" >
<tr >
  <td width="150">Name:</td>
  <td width="150"> <?php echo $_SESSION['name']; ?></td>
</tr>
<tr>
  <td width="150"  >Admission No:</td>
  <td width="150"><?php echo $_SESSION['admission_no']; ?></td>
</tr>
<tr>
  <td width="150">Year:</td>
  <td width="150"><?php echo $_SESSION['year']; ?></td>
</tr>
<tr>
  <td width="150">Mark:</td>
  <td width="150"><?php echo $_SESSION['mark']; ?></td>
</tr>
<tr>
  <td width="150">Distance:</td>
  <td width="150"><?php echo $_SESSION['distance']; ?></td>
</tr>
<tr>
  <td width="150">Category:</td>
  <td width="150"><?php
  if($_SESSION['reservation_id']==1){
    echo 'General'; }
    elseif($_SESSION['reservation_id']==2){
      echo 'Obc'; }
      elseif($_SESSION['reservation_id']==3){
        echo 'Oec'; }
        elseif($_SESSION['reservation_id']==4){
          echo 'Sc-St'; }
          else{
            echo 'Others';
          }

  ?></td>
</tr>

<tr >
  <td width="150">Rank Point</td>
  <td width="150"> <?php if($verified==1){echo 0;}else{echo $rank_point; }?></td>
</tr>
<tr >
  <td width="150">Verification Status</td>
  <td width="150"> <?php if($verified==0){echo "Verification Pending";}else if($verified==1){echo "Application Rejected"; }else{echo"Application Accepted";}?></td>
</tr>
<tr >
  <td width="150">Rank</td>
  <td width="150"> <?php if($verified==1){echo 0;}else{if($rank==NULL){echo "Rank not published";}else{echo $rank; }}?></td>
</tr>
</table>
<br/>
<p><a href="edit.php">Edit Profile</a></p>
<p><a href="delete.php">Delete Profile</a></p>
<p><a href="logout.php">Logout</a></p>
</div></div></div></div>
</body>
</html>
