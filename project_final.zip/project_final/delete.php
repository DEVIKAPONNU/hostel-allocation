<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<?php
require('db.php');
// If form submitted, insert values into the database.
$ad=$_SESSION['admission_no'];

$query = "delete from `students`
WHERE `students`.`admission_no` = '$ad';";
$result=mysqli_query($con,$query);
if($result){
  header("Location: login.php");
}
?>
