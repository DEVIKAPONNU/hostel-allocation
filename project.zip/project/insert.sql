INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b111","Devika","abcd",3,8,258,4);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b222","Anjaly","abcd",2,9,90,1);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b333","Ayisha","abcd",1,7,258,2);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b444","Aiswarya","abcd",3,8,158,3);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b555","Shamla","abcd",3,8,741,4);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b666","Afeefa","abcd",3,8,568,3);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b777","Anju","abcd",3,8,108,1);
INSERT INTO `students`(`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`) VALUES ("16b888","Dersana","abcd",4,8,258,4);
