<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Admin</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <?php
  require('db.php');
  // If form submitted, insert values into the database.
  if (isset($_REQUEST['notify'])){
    $notification=$_REQUEST['notification'];
    $_SESSION['notification'] = $notification;
header("Location: home.php"); 
  }
  ?>
<h2>Edit Notification</h2>
<font color="red">*</font>Enter &lt;br/&gt; for new line
<form action="" name="notify" method="post">
<textarea name="notification"cols="100" rows="30"></textarea><br/></br/>
<input name="notify" type="submit" value="Notify" /><br/><br/><a href="admin.php">Cancel</a>
</form>
</center>
</div>
</body>
</html>
