<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<!--<link rel="stylesheet" href="css/style.css" />-->
<link href="login.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  <link href="css/main.css" rel="stylesheet" media="all">
</head>
<body>
<?php
require('db.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['admission_no'])){
        // removes backslashes
	$admission_no= stripslashes($_REQUEST['admission_no']);
        //escapes special characters in a string
	$admission_no = mysqli_real_escape_string($con,$admission_no);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	if($admission_no=='admin' and $password=='admin'){
		$_SESSION['admission_no'] = $admission_no;
		header("Location: admin.php");
	}
	else{
	//Checking is user existing in the database or not
  $query = "SELECT * FROM `students` WHERE admission_no='$admission_no' and password='$password'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
    if($rows==1){
          while($r=$result->fetch_object()){
						$name=$r->name;
						$year=$r->year;
						$mark=$r->mark;
						$distance=$r->distance;
						$reservation_id=$r->reservation_id;
          }
	    $_SESSION['admission_no'] = $admission_no;
      $_SESSION['name']=$name;
			$_SESSION['year']=$year;
			$_SESSION['mark']=$mark;
			$_SESSION['distance']=$distance;
			$_SESSION['reservation_id']=$reservation_id;
            // Redirect user to student.php

	    header("Location: student.php");
         }else{
	echo "<div class='form'>
<h3>Username/password is incorrect.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
}}
    }else{
?>
<div class="wrapper fadeInDown">
  <div id="formContent"  style="width:350px">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
	<a href="home.html">
     <img src="images.jpeg" id="icon" alt="User Icon" class="img"/>
	</a>
      <h1>STUDENT LOGIN</h1>
    </div>

    <!-- Login Form -->
    <form name="login"class="login100-form validate-form" action="" method="post">

					<div style="width: 92%" >
						<input class="input100" type="text" name="admission_no" placeholder="Admission No">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div style="width: 92%" data-validate = "Password is required">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>

					<div class="container-login100-form-btn">
						<input type="submit" name="login"class="fadeIn fourth" value="Log In">
					</div>

				</form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="home.php">Go to the Site</a>&emsp;&emsp;
      <a class="underlineHover" href="registration.php">Register</a>
    </div>

  </div>
</div>
<?php } ?>
</body>
</html>
