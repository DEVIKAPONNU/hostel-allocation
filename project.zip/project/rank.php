<?php
//include auth.php file on all secure pages
include("auth.php");
require('db.php');
$query = "SELECT * FROM `general` order by `rank_point` desc;";
$result = mysqli_query($con,$query) or die(mysql_error());
$i=1;
while($r=$result->fetch_object()){
					$admission_no=$r->admission_no;
					$q1="UPDATE `general` SET `rank`='$i' where `admission_no`='$admission_no'";
					$res1=mysqli_query($con,$q1) or die(mysql_error());
					$i++;
}
$query = "SELECT * FROM `sc_st` order by `rank_point` desc;";
$result = mysqli_query($con,$query) or die(mysql_error());
$i=1;
while($r=$result->fetch_object()){
         $admission_no=$r->admission_no;
         $q2="UPDATE `sc_st` SET `rank`='$i' where `admission_no`='$admission_no'";
         $res2=mysqli_query($con,$q2) or die(mysql_error());
         $i++;
         $true=1;
}
if($res1){
  $true=1;
echo "<p>Rank Generated</p><a href='admin.php'>Back</a>";}
 ?>
