<?php
require('db.php');
if (isset($_POST['login'])) {
		$username = $_POST['admission_no'];
		$password = $_POST['password'];



		 $query3 = "SELECT * FROM students WHERE admission_no ='$username' AND password='$password'";
			$results3 = mysqli_query($con, $query3);

			if (!mysqli_num_rows($results3) == 1)
				{ 	$passworderr  = "Invalid Username or Password"; }

								}


 ?>
