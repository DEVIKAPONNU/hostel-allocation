<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
	<title>
		Registration
	</title>
	<link href="login.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
	<!------ Include the above in your HEAD tag ---------->
	<link href="login/css/main.css" rel="stylesheet" media="all">
	<style>
	select{
	  color: #999999;
	  width: 400px;
	  border-radius: 2px;
	  border: 1px solid #CCC;
	  padding: 15px;
	  font-size: 14px;
	  margin-top: 10px;
		margin-right: 10px;
		margin-left:5px;
	}
	option{
	  width: 400px;
	  border-radius: 2px;
	  border: 1px solid #CCC;
	  padding: 15px;
	  color: #333;
	  font-size: 14px;
	  margin-top: 10px;

	}
	</style>
</head>
<body class="image-login">
<?php
	require('db.php');
	// If form submitted, insert values into the database.
	if (isset($_REQUEST['admission_no'])){
        // removes backslashes
		$admission_no = stripslashes($_REQUEST['admission_no']);
        //escapes special characters in a string
		$admission_no = mysqli_real_escape_string($con,$admission_no);
		$name = stripslashes($_REQUEST['name']);
		$name = mysqli_real_escape_string($con,$name);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		$year = stripslashes($_REQUEST['year']);
		//	$year = mysqli_real_escape_string($con,$year);
		$mark = stripslashes($_REQUEST['mark']);
		//	$mark = mysqli_real_escape_string($con,$mark
		if($mark>=9 && $mark<=10 ){
			$rank_point=50;
		}
		elseif($mark>=8 && $mark<9 ){
			$rank_point=40;
		}
		elseif($mark>=7 && $mark<8 ){
			$rank_point=30;
		}
		elseif($mark>=6 && $mark<7 ){
			$rank_point=25;
		}
		elseif($mark>10){
			$rank_point=0;
		}
		else{
			$rank_point=15;
		}

		$distance = stripslashes($_REQUEST['distance']);
		if($distance>=350){
			$rank_point+=50;
		}
		elseif($distance>=300 && $distance<350 ){
			$rank_point+=45;
		}
		elseif($distance>=250 && $distance<300 ){
			$rank_point+=40;
		}
		elseif($distance>=200 && $distance<250 ){
			$rank_point+=35;
		}
		elseif($distance>=100 && $distance<200 ){
			$rank_point+=25;
		}
		elseif($distance>=50 && $distance<100 ){
			$rank_point+=20;
		}
		else{
			$rank_point+=10;
		}
		//	$distance = mysqli_real_escape_string($con,$distance);
		$reservation_id = stripslashes($_REQUEST['reservation_id']);
		//	$reservation_id = mysqli_real_escape_string($con,$reservation_id);

		$query = "INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`, `distance`,`reservation_id`,`verified`)
			VALUES ('$admission_no', '$name', '$password', '$year', '$mark', '$distance','$reservation_id',0);";
		$result = mysqli_query($con,$query);
		if($result){
			if($reservation_id==4){
				$query = "INSERT INTO `sc_st` (`admission_no`, `rank_point`,`rank`)
					VALUES ('$admission_no', '$rank_point',NULL);";
					mysqli_query($con,$query);
			}
			else{
				$query = "INSERT INTO `general` (`admission_no`, `rank_point`,`rank`)
					VALUES ('$admission_no', '$rank_point',NULL);";
					mysqli_query($con,$query);
			}
            echo "<div class='form'>
			<h3>You are registered successfully.<br/>Your Username is </h3><h2>$admission_no
			<br/>Click here to <a href='login.php'>Login</a></div>";
        }else{
					echo "<center><p>Invalid registration!</p></center>";
					echo "<div class='form'>
<p><a href='registration.php'>Re-Register</a></p></div>";
				}
    }else{
?>
<div class="wrapper fadeInDown">
	<div id="formContent" >
		<div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
			<div class="wrapper wrapper--w680" style="padding-left:5px">
				<div class="card card-4">
					<div class="card-body">
						<div class="form">
							<h1>Registration</h1>
								<form name="registration"  action="" method="post">
									<div style="width: 87%" >
										<input class="input100" type="text" name="admission_no" placeholder="Admission No">
									</div>
									<div style="width: 87%" >
										<input type="Text" Name="name" class="input--style-4" placeholder="Name" required/>
									</div>
									<div style="width: 87%" >
										<input type="password" Name="password" class="input--style-4" placeholder="Password" size="30" required/><br>
									</div>
										<div style="width: 87%" >
										<input type="Text" class="input--style-4" Name="mark" placeholder="cgpa or equivalent"required/>
									</div>
									<div style="width: 87%" >
										<input type="Text" class="input--style-4" Name="distance" placeholder="Distance"required/>
									</div>

									<div class="row row-space">
										<div class="col-2">
											<div class="input-group">
												<select name="year" required  >
												<option value=""hidden>year</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
												</select>
												<select name="reservation_id"required>
												<option value=""hidden>Category</option>
												<option value="01">1.General</option>
												<option value="02">2.Obc</option>
												<option value="03">3.Oec</option>
												<option value="04">4.Sc-st</option>
												<option value="05">5.Others</option>
												</select>

											</div>
										</div>
									</div>
									<br><br>
									<input type="submit" name="register" value="Register" />
								</form>
								<a href="home.php">Go To Site</a> &nbsp;&nbsp;
								<a href="login.php">Log in</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
</body>
</html>
