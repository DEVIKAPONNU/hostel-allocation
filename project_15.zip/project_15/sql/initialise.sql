drop database if exists hostel_allocation;
create database if not exists hostel_allocation;
use hostel_allocation;


create table students(
    admission_no varchar(30),
    primary key(admission_no),
    name varchar(80),
    password varchar(20),
    year int,
    mark float(10),
    distance float(10),
    reservation_id int,
    verified int
  )ENGINE=InnoDB
  COLLATE utf8_general_ci;


create table general(
    admission_no varchar(30),
    FOREIGN KEY (admission_no) REFERENCES students(admission_no) ON DELETE CASCADE,
    rank_point int  DEFAULT NULL,
    rank int
  )ENGINE=InnoDB
  COLLATE utf8_general_ci;
  create table sc_st(
      admission_no varchar(30),
      FOREIGN KEY (admission_no) REFERENCES students(admission_no) ON DELETE CASCADE,
      rank_point int DEFAULT NULL,
      rank int
    )ENGINE=InnoDB
    COLLATE utf8_general_ci;
