drop database if exists hostel_allocation;
create database if not exists hostel_allocation;
use hostel_allocation;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE `general` (
  `admission_no` varchar(30) DEFAULT NULL,
  `rank_point` int(11) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `general` (`admission_no`, `rank_point`, `rank`) VALUES
('16b189', 70, NULL),
('1234', 75, NULL),
('567', 100, NULL);

CREATE TABLE `sc_st` (
  `admission_no` varchar(30) DEFAULT NULL,
  `rank_point` int(11) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `sc_st` (`admission_no`, `rank_point`, `rank`) VALUES
('16b134', 65, NULL),
('4567', 75, NULL),
('7890', 90, NULL);


CREATE TABLE `students` (
  `admission_no` varchar(30) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `mark` float DEFAULT NULL,
  `distance` float DEFAULT NULL,
  `reservation_id` int(11) DEFAULT NULL,
  `verified` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`, `verified`) VALUES
('1234', 'adhithya', 'abcd', 3, 9, 179, 2, 0),
('16b134', 'devika', 'abcdq', 3, 8, 100, 4, 0),
('16b189', 'Aiswarya', 'abcd', 3, 9, 78, 2, 0),
('4567', 'ANJALI', 'abcd', 3, 7, 300, 4, 0),
('567', 'rani', 'abcd', 3, 9, 780, 1, 0),
('7890', 'kripa', 'abcd', 3, 8, 800, 4, 0);


ALTER TABLE `general`
  ADD KEY `admission_no` (`admission_no`);

ALTER TABLE `sc_st`
  ADD KEY `admission_no` (`admission_no`);

ALTER TABLE `students`
  ADD PRIMARY KEY (`admission_no`);

ALTER TABLE `general`
  ADD CONSTRAINT `general_ibfk_1` FOREIGN KEY (`admission_no`) REFERENCES `students` (`admission_no`) ON DELETE CASCADE;

ALTER TABLE `sc_st`
  ADD CONSTRAINT `sc_st_ibfk_1` FOREIGN KEY (`admission_no`) REFERENCES `students` (`admission_no`) ON DELETE CASCADE;
COMMIT;
