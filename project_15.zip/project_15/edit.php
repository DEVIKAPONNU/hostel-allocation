<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Edit</title>
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="main.css" />
</head>
<body class="image-login">
<?php
require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['change'])){
  $ad=$_SESSION['admission_no'];
  if(isset($_POST['name_new'])){
  	$name_new = stripslashes($_REQUEST['name_new']);
  	$name_new = mysqli_real_escape_string($con,$name_new);
    if($name_new!=NULL){
      $query = "UPDATE `students`
      SET `name` = '$name_new'
      WHERE `students`.`admission_no` = '$ad';";
      mysqli_query($con,$query);
  }
  }
  if(isset($_POST['password_new'])){
  	$password_new = stripslashes($_REQUEST['password_new']);
  	$password_new = mysqli_real_escape_string($con,$password_new);
    if($password_new!=NULL){
      $query = "UPDATE `students`
      SET `password` = '$password_new'
      WHERE `students`.`admission_no` = '$ad';";
      mysqli_query($con,$query);
  }
  }
  if(isset($_POST['year_new'])){
  	$year_new = stripslashes($_REQUEST['year_new']);
  	$year_new = mysqli_real_escape_string($con,$year_new);
    if($year_new!=NULL){
      $query = "UPDATE `students`
      SET `year` = '$year_new'
      WHERE `students`.`admission_no` = '$ad';";
      mysqli_query($con,$query);
  }
  }
  if(isset($_POST['mark_new'])){
  	$mark_new = stripslashes($_REQUEST['mark_new']);
  	$mark_new = mysqli_real_escape_string($con,$mark_new);
    if($mark_new!=NULL){
      $query = "UPDATE `students`
      SET `mark` = '$mark_new'
      WHERE `students`.`admission_no` = '$ad';";
      mysqli_query($con,$query);
    }
  }else{
    $mark_new=$_SESSION['mark'];
  }
  if(isset($_POST['distance_new'])){
    $distance_new = stripslashes($_REQUEST['distance_new']);
    $distance_new = mysqli_real_escape_string($con,$distance_new);
    if($distance_new!=NULL){
      $query = "UPDATE `students`
      SET `distance` = '$distance_new'
      WHERE `students`.`admission_no` = '$ad';";
      mysqli_query($con,$query);
    }
  }else{
    $distance_new=$_SESSION['distance'];
  }
  if($mark_new>=9 && $mark_new<=10 ){
    $rank_point=50;
  }
  elseif($mark_new>=8 && $mark_new<9 ){
    $rank_point=40;
  }
  elseif($mark_new>=7 && $mark_new<8 ){
    $rank_point=30;
  }
  elseif($mark_new>=6 && $mark_new<7 ){
    $rank_point=25;
  }
  elseif($mark_new>10){
    $rank_point=0;
  }
  else{
    $rank_point=15;
  }

  if($distance_new>=350){
    $rank_point+=50;
  }
  elseif($distance_new>=300 && $distance_new<350 ){
    $rank_point+=45;
  }
  elseif($distance_new>=250 && $distance_new<300 ){
    $rank_point+=40;
  }
  elseif($distance_new>=200 && $distance_new<250 ){
    $rank_point+=35;
  }
  elseif($distance_new>=100 && $distance_new<200 ){
    $rank_point+=25;
  }
  elseif($distance_new>=50 && $distance_new<100 ){
    $rank_point+=20;
  }
  else{
    $rank_point+=10;
  }
  if(isset($_POST['reservation_id_new'])){
    $reservation_id_new = stripslashes($_REQUEST['reservation_id_new']);
    $reservation_id_new = mysqli_real_escape_string($con,$reservation_id_new);
    if($reservation_id_new!=NULL){
      $query = "UPDATE `students`
      SET `reservation_id` = '$reservation_id_new'
      WHERE `students`.`admission_no` = '$ad';";
      $result=mysqli_query($con,$query);
    }
  }
    else{
      $reservation_id_new=$_SESSION['reservation_id'];
    }

      $reservation_id_old=$_SESSION['reservation_id'];
      if($reservation_id_new==4){
        if($reservation_id_old!=4){
          $query = "delete from `general`
          WHERE `general`.`admission_no` = '$ad';";
          mysqli_query($con,$query);
          $query = "INSERT INTO `sc_st` (`admission_no`, `rank_point`,`rank`)
  					VALUES ('$ad', '$rank_point',NULL);";
  					mysqli_query($con,$query);
        }else{
          $query1 = "UPDATE `sc_st`
          SET `rank_point` = '$rank_point'
          WHERE `sc_st`.`admission_no` = '$ad';";
            mysqli_query($con,$query1);
        }

      }
      else{

        if($reservation_id_old==4){
          $query = "delete from `sc_st`
          WHERE `sc_st`.`admission_no` = '$ad';";
          mysqli_query($con,$query);
          $query = "INSERT INTO `general` (`admission_no`, `rank_point`,`rank`)
  					VALUES ('$ad', '$rank_point',NULL);";
  					mysqli_query($con,$query);
        }else{
          $query1= "UPDATE `general`
          SET `rank_point` = '$rank_point'
          WHERE `general`.`admission_no` = '$ad';";
            mysqli_query($con,$query1);
        }

      }


      echo "<div class='form'><p>Profile updated<br/>.....................</p>
      <a href='logout.php'>Re-log </a>
      </div>";

}else{
?>
<div class="wrapper ">
	<div id="formContent" >
			<div class="wrapper " style="padding-left:1px">
				<div class="card">
					<div class="card-body">
						<div class="form"><h2><b>EDIT PROFILE</b></h2><br/>
<!--<p>Welcome <?php echo $_SESSION['name']; ?><br/>
Mark:<?php echo $_SESSION['mark']; ?><br/>Distance:<?php echo $_SESSION['distance']; ?></p>-->
<form action="edit.php" method="post" name="change">
<table valign="left" style="text-align: left" >
<tr>
  <td style="text-align: left" >Name:</td>
<td width="230"><input type="text" class="input100" name="name_new" placeholder="<?php echo $_SESSION['name']; ?>"  /></td></tr>
<tr>
  <td width="230" >Password:</td>
<td width="230"><input type="text" name="password_new" /></td></tr>
<tr>
  <td width="230">Year:</td>
<td width="230">
  <select name="year_new">
  <option value=""hidden><?php echo $_SESSION['year']; ?></option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  </select>
  </td>
</tr>
<tr>
  <td width="230">Mark:</td>
<td width="230"><input type="text" name="mark_new" placeholder="<?php echo $_SESSION['mark']; ?>"  /></td></tr>
<tr>
  <td width="230">Distance:</td>
<td width="230"><input type="text" name="distance_new" placeholder="<?php echo $_SESSION['distance']; ?>"  /></td></tr>
<tr>
  <td width="230">Category:</td>
<td width="230">
  <select name="reservation_id_new">
  <option value=""hidden><?php echo $_SESSION['reservation_id']; ?></option>
  <option value="01">1.general</option>
  <option value="02">2.obc</option>
  <option value="03">3.oec</option>
  <option value="04">4.sc-st</option>
  <option value="05">5.others</option>
  </select>
</td></tr>
</table>
<br/>
<input name="change" type="submit" value="Change" />
</form><p>
<a href="student.php">Cancel</a>
</p>
<a href="logout.php">Logout</a>
</div>
</div></div></div></div></div></div>
<?php } ?>
</body>
</html>
