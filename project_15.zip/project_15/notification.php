<?php
//include auth.php file on all secure pages
include("auth.php");
include("db.php");

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Admin</title>
<link rel="stylesheet" href="stylea.css">
<link rel="stylesheet" href="main.css">
<link rel="stylesheet" href="css/style.css" />
</head>
<body class="image-login"><BR/><BR/><bR/><BR/>
  <table ><tr ><td style="padding:50px;">
    <h2 style="color:#007399;">NOTIFICATIONS</h2><br/><br/>
  <font size="4" color="black">
 <?php echo $_SESSION['notification']; ?></font>
 <br/><br/>
<br/>
 <a href="home.php"><font size="5">home</font></a>
</td></tr></table>

</body>
</html>
