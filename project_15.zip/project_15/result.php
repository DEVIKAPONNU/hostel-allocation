<?php
require('db.php'); ?><html>
<head><title>Result</title>
<link rel="stylesheet" href="stylea.css">
<link rel="stylesheet" href="main.css">
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body class="image-login"><centeR><br/><Br/>
<h2><font color="black"><center>General</center></font></h2><br/><Br/><table>
<?php
$query = "SELECT * FROM `general`,`students` where `general`.`admission_no`=`students`.`admission_no` order by `rank` limit 80;";
$result = mysqli_query($con,$query) or die(mysql_error());
$rows = mysqli_num_rows($result);
if($rows==0){
  echo "Missing Entries!!!";
}
else{
  echo"<tr><td>&nbsp&nbsp&nbspRANK&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspADMISSION_NO&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspNAME&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspMARK&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspDISTANCE&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspRANK POINT&nbsp&nbsp&nbsp</td></tr>";
		while($r=$result->fetch_object()){
							$admission_no=$r->admission_no;
							$rank_point=$r->rank_point;
							$rank=$r->rank;
              $name=$r->name;
              $distance=$r->distance;
              $mark=$r->mark;
							if($rank){
							echo "<tr><td>$rank</td><td>&nbsp&nbsp&nbsp$admission_no";
							echo "&nbsp&nbsp&nbsp</td><td>$name";
							echo "</td><td>$mark</td><td>$distance</td><td>$rank_point</td><tr/>";
						}else{
							echo "Rank Not Published";
							break;
						}
		}}

 ?>
</center></table><br/><Br/>
<h2><font color="black"><center>SC-ST</center></font></h2><br/><Br/><table>
 <?php
$query = "SELECT * FROM `sc_st`,`students` where `sc_st`.`admission_no`=`students`.`admission_no` order by `rank` limit 20;";
 $result = mysqli_query($con,$query) or die(mysql_error());
 $rows = mysqli_num_rows($result);
 if($rows==0){
   echo "Missing Entries!!!";
 }
 else{
   echo"<tr><td>&nbsp&nbsp&nbspRANK&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspADMISSION_NO&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspNAME&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspMARK&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspDISTANCE&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspRANK POINT&nbsp&nbsp&nbsp</td></tr>";
	 while($r=$result->fetch_object()){
	 					$admission_no=$r->admission_no;
	 					$rank_point=$r->rank_point;
	 					$rank=$r->rank;
            $name=$r->name;
            $distance=$r->distance;
            $mark=$r->mark;
						if($rank){
              echo "<tr><td>$rank</td><td>&nbsp&nbsp&nbsp$admission_no";
              echo "&nbsp&nbsp&nbsp</td><td>$name";
              echo "</td><td>$mark</td><td>$distance</td><td>$rank_point</td><tr/>";
					}else{
						echo "Rank Not Published";
						break;
					}

	 }}

   ?><br/><br/>
   <a href="admin.php" >
          <font color="#0000ff" size="5">
          <b>
            &nbsp;&nbsp;&nbsp;Admin
          </b>
          </a>
          <a href="home.php" >
                 <font color="#0000ff" size="5">
                 <b>
                   &nbsp;&nbsp;&nbsp;Home
                 </b>
                 </a>
</table>
</p>
</body>
</html>
