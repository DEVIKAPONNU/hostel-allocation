drop database if exists hostel_allocation;
create database if not exists hostel_allocation;
use hostel_allocation;

create table hostels(
  id int,
  primary key(id),
  name varchar(80),
  capacity int
)ENGINE=InnoDB
COLLATE utf8_general_ci;

INSERT INTO `hostels` (`id`, `name`, `capacity`)
VALUES ('100', 'lh1', '100');
INSERT INTO `hostels` (`id`, `name`, `capacity`)
VALUES ('101', 'lh2', '150');
INSERT INTO `hostels` (`id`, `name`, `capacity`)
VALUES ('102', 'lh3', '160');

create table reservation(
  id int,
  primary key(id),
  caste varchar(80),
  weightage float(10)
)ENGINE=InnoDB
COLLATE utf8_general_ci;

INSERT INTO `reservation` (`id`, `caste`, `weightage`)
VALUES ('01', 'general', '0');
INSERT INTO `reservation` (`id`, `caste`, `weightage`)
VALUES ('02', 'obc', '5');
INSERT INTO `reservation` (`id`, `caste`, `weightage`)
VALUES ('03', 'oec', '6');
INSERT INTO `reservation` (`id`, `caste`, `weightage`)
VALUES ('04', 'sc-st', '8');
INSERT INTO `reservation` (`id`, `caste`, `weightage`)
VALUES ('05', 'others', '0');


create table students(
    admission_no varchar(30),
    primary key(admission_no),
    name varchar(80),
    password varchar(20),
    year int,
    mark float(10),
    distance float(10),
    reservation_id int,
    FOREIGN KEY (reservation_id) REFERENCES reservation(id),
    rank float(10) null,
    hostel_id int null,
    FOREIGN KEY (hostel_id) REFERENCES hostels(id)
  )ENGINE=InnoDB
  COLLATE utf8_general_ci;

INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`, `rank`, `hostel_id`)
VALUES ('16b189', 'aiswarya', 'abcd', '3', '8.7', '38', '3', NULL, NULL);
