<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
require('db.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['admission_no'])){
        // removes backslashes
	$admission_no= stripslashes($_REQUEST['admission_no']);
        //escapes special characters in a string
	$admission_no = mysqli_real_escape_string($con,$admission_no);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	if($admission_no=='admin' and $password=='admin'){
	  echo "admin";
		$_SESSION['admission_no'] = $admission_no;
		header("Location: admin.php");
	}
	else{
	//Checking is user existing in the database or not
  $query = "SELECT * FROM `students` WHERE admission_no='$admission_no' and password='$password'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
    if($rows==1){
          while($r=$result->fetch_object()){
            $name=$r->name;
						$year=$r->year;
						$mark=$r->mark;
						$distance=$r->distance;
						$reservation_id=$r->reservation_id;
          }
	    $_SESSION['admission_no'] = $admission_no;
      $_SESSION['name']=$name;
			$_SESSION['year']=$year;
			$_SESSION['mark']=$mark;
			$_SESSION['distance']=$distance;
			$_SESSION['reservation_id']=$reservation_id;
            // Redirect user to index.php
	    header("Location: index.php");
         }else{
	echo "<div class='form'>
<h3>Username/password is incorrect.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
}}
    }else{
?>
<div class="form">
<h1>Log In</h1>
<form action="" method="post" name="login">
<input type="text" name="admission_no" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<input name="login" type="submit" value="Login" />
</form>
<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
</div>
<?php } ?>
</body>
</html>
