<?php
$t=285;
if($t<30 AND $t>20 )
  echo "true";
else
  echo "false";?>
