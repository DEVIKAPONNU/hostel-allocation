<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['admission_no'])){
        // removes backslashes
	$admission_no = stripslashes($_REQUEST['admission_no']);
        //escapes special characters in a string
	$admission_no = mysqli_real_escape_string($con,$admission_no);
	$name = stripslashes($_REQUEST['name']);
	$name = mysqli_real_escape_string($con,$name);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	$year = stripslashes($_REQUEST['year']);
//	$year = mysqli_real_escape_string($con,$year);
	$mark = stripslashes($_REQUEST['mark']);
//	$mark = mysqli_real_escape_string($con,$mark
	$distance = stripslashes($_REQUEST['distance']);
//	$distance = mysqli_real_escape_string($con,$distance);
	$reservation_id = stripslashes($_REQUEST['reservation_id']);
//	$reservation_id = mysqli_real_escape_string($con,$reservation_id);
  $query = "INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`, `rank`, `hostel_id`)
			VALUES ('$admission_no', '$name', '$password', '$year', '$mark', '$distance', '$reservation_id', NULL, NULL);";
  $result = mysqli_query($con,$query);
  if($result){
            echo "<div class='form'>
<h3>You are registered successfully.<br/>Your Username is </h3><h2>$admission_no
<br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{
?>
<div class="form">
<h1>Registration</h1>
<form name="registration" action="" method="post">
<input type="Text" Name="admission_no" placeholder="Admission No" required/>
<input type="Text" Name="name" placeholder="Name" required/>
<input type="password" Name="password" placeholder="Password" required/>

<select name="year" required>
<option value=""hidden>year</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
</select>
<input type="Text" Name="mark" placeholder="cgpa or equivalent"required/>
<input type="Text" Name="distance" placeholder="Distance"required/>
<select name="reservation_id"required>
<option value=""hidden>Category</option>
<option value="01">general</option>
<option value="02">obc</option>
<option value="03">oec</option>
<option value="04">sc-st</option>
<option value="05">others</option>
</select>

<input type="submit" name="register" value="Register" />
</form>
</div>
<?php } ?>
</body>
</html>
