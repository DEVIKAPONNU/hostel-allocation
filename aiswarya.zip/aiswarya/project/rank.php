<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="stylea.css">
<link rel="stylesheet" href="main.css">
<style>
/* Center the loader */
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #13496c;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 }
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom {
  from{ bottom:-100px; opacity:0 }
  to{ bottom:0; opacity:1 }
}

#myDiv {
	display: none;
  text-align: left;
}
</style>
</head>
<?php
//include auth.php file on all secure pages
include("auth.php");
require('db.php');
$query = "SELECT * FROM `general` order by `rank_point` desc;";
$result = mysqli_query($con,$query) or die(mysql_error());
$i=1;
while($r=$result->fetch_object()){
					$admission_no=$r->admission_no;
					$q1="UPDATE `general` SET `rank`='$i' where `admission_no`='$admission_no'";
					$res1=mysqli_query($con,$q1) or die(mysql_error());
					$i++;
}
$query = "SELECT * FROM `sc_st` order by `rank_point` desc;";
$result = mysqli_query($con,$query) or die(mysql_error());
$i=1;
while($r=$result->fetch_object()){
         $admission_no=$r->admission_no;
         $q2="UPDATE `sc_st` SET `rank`='$i' where `admission_no`='$admission_no'";
         $res2=mysqli_query($con,$q2) or die(mysql_error());
         $i++;
         $true=1;
}
?>
<body class="image-login" onload="myFunction()" style="margin:0;">

<div id="loader"></div>

<div style="display:none;" id="myDiv" class="animate-bottom">
  <h2><FONT COLOR="BLACK">Rank Generated</FONT></h2><br/>
  <H2><FONT COLOR="black"><a href="admin.php"><b>Back</b></a></FONT></H2>
</div>

<script>
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>

</body>
</html>
