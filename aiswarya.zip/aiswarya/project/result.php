<?php
require('db.php'); ?><html>
<head><title>Result</title>
<link rel="stylesheet" href="stylea.css">
<link rel="stylesheet" href="main.css">
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body class="image-login"><centeR><br/><Br/>
<h2><font color="black"><center>General</center></font></h2><br/><Br/><table>
<?php
echo"<tr><td>&nbsp&nbsp&nbspRANK&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspADMISSION_NO&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspRANK POINT&nbsp&nbsp&nbsp</td></tr>";
$query = "SELECT * FROM `general` order by `rank`;";
$result = mysqli_query($con,$query) or die(mysql_error());
		while($r=$result->fetch_object()){
							$admission_no=$r->admission_no;
							$rank_point=$r->rank_point;
							$rank=$r->rank;
							if($rank){
							echo "<tr><td>$rank</td><td>&nbsp&nbsp&nbsp$admission_no";
							echo "&nbsp&nbsp&nbsp</td><td>$rank_point";
							echo "</td><tr/>";
						}else{
							echo "Rank Not Published";
							break;
						}
		}

 ?>
</center></table><br/><Br/>
<h2><font color="black"><center>SC-ST<br/><Br/></center></font></h2><table>
 <?php
 echo"<tr><td>&nbsp&nbsp&nbspRANK&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspADMISSION_NO&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbspRANK POINT&nbsp&nbsp&nbsp</td></tr>";
 $query = "SELECT * FROM `sc_st` order by `rank` limit 20;";
 $result = mysqli_query($con,$query) or die(mysql_error());
	 while($r=$result->fetch_object()){
	 					$admission_no=$r->admission_no;
	 					$rank_point=$r->rank_point;
	 					$rank=$r->rank;
						if($rank){
						echo "<tr><td>$rank</td><td>&nbsp&nbsp&nbsp$admission_no";
						echo "&nbsp&nbsp&nbsp</td><td>$rank_point";
						echo "</td><tr/>";
					}else{
						echo "Rank Not Published";
						break;
					}

	 }

   ?>
</table>
</p>
</body>
</html>
