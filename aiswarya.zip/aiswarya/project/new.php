<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
	<title>
		Login
	</title>
	<link href="login.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
	<!------ Include the above in your HEAD tag ---------->
	<link href="login/css/main.css" rel="stylesheet" media="all">
</head>
<body class="image-login">
<?php
	require('db.php');
	// If form submitted, insert values into the database.
	if (isset($_REQUEST['admission_no'])){
        // removes backslashes
		$admission_no = stripslashes($_REQUEST['admission_no']);
        //escapes special characters in a string
		$admission_no = mysqli_real_escape_string($con,$admission_no);
		$name = stripslashes($_REQUEST['name']);
		$name = mysqli_real_escape_string($con,$name);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		$year = stripslashes($_REQUEST['year']);
		//	$year = mysqli_real_escape_string($con,$year);
		$mark = stripslashes($_REQUEST['mark']);
		//	$mark = mysqli_real_escape_string($con,$mark
		$distance = stripslashes($_REQUEST['distance']);
		//	$distance = mysqli_real_escape_string($con,$distance);
		$reservation_id = stripslashes($_REQUEST['reservation_id']);
		$reservation_id = mysqli_real_escape_string($con,$reservation_id);
		if($mark>=9 && $mark<=10)
		{
			$rank= $rank+50;
		}
		$query = "INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`,'reservation_id', `distance`, `rank`, `hostel_id`)
			VALUES ('$admission_no', '$name', '$password', '$year', '$mark', '$distance','$reservation_id','$rank', NULL);";
		$result = mysqli_query($con,$query);
		if($result){
			echo"$rank";
            echo "<div class='form'>
			<h3>You are registered successfully.<br/>Your Username is </h3><h2>$admission_no 
			<br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{
?>
<div class="wrapper fadeInDown">
	<div id="formContent" >
		<div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
			<div class="wrapper wrapper--w680" style="padding-left:5px">
				<div class="card card-4">
					<div class="card-body">
						<div class="form">
							<h1>Registration</h1>
								<form name="registration"  action="" method="post">
									<div style="width: 87%" >
										<input class="input100" type="text" name="admission_no" placeholder="Admission No">
									</div>
									<div style="width: 87%" >
										<input type="Text" Name="name" class="input--style-4" placeholder="Name" required/>
									</div>
									<div style="width: 87%" >
										<input type="password" Name="password" class="input--style-4" placeholder="Password" size="30" required/><br>
									</div>
										<div style="width: 87%" >
										<input type="Text" class="input--style-4" Name="mark" placeholder="cgpa or equivalent"required/>
									</div>
									<div style="width: 87%" >
										<input type="Text" class="input--style-4" Name="distance" placeholder="Distance"required/>
									</div>
									<br>
									<div class="row row-space">
										<div class="col-2">
											<div class="input-group">
												<label class="label">Year</label>
													<select name="year" >
														<option disabled="disabled" selected="selected">Choose option</option>
														<option>1</option>
														<option>2</option>
														<option>3</option>
														<option>4</option>
													</select>
												<label class="label">Category</label>
													<select name="reservation_id" >
														<option disabled="disabled" selected="selected">Choose option</option>
														<option>General</option>
														<option>OBC</option>
														<option>OEC</option>
														<option>SC/ST</option>
													</select>
											</div>
										</div>
									</div>
									<br><br>
									<input type="submit" name="register" value="Register" />
								</form>
								<a href="home.html">Go To Site</a> &nbsp;&nbsp;
								<a href="login.php">Log in</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
</body>
</html>
