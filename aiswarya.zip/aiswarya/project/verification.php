<html>
<head>
  <link rel="stylesheet" href="main.css" />
  <title>
    VERIFICATION
  </title>
  <style>
  table, th, td {
      border: 1px solid black;
      width:40%;
      height:25px;
  }
  input[type=checkbox] {
    zoom: 1.7;
}
  </style>
</head>
<body class="image-login">
<?php
require('db.php');
if (isset($_POST['verified'])){
  $query = "SELECT admission_no FROM `students`;";
  $result = mysqli_query($con,$query) or die(mysql_error());
  $rows = mysqli_num_rows($result);
  for($i=0;$i<$rows;$i++){
    while($r=$result->fetch_object()){
      $admission_no=$r->admission_no;
      if(isset($_POST[$admission_no]) && $_POST[$admission_no] =='verified'){
        $query = "INSERT INTO `verified` (`admission_no`)
          VALUES ('$admission_no');";
          mysqli_query($con,$query);
        }
      }

}
$query1= "DELETE FROM `students` WHERE `students`.`admission_no` NOT IN (select * from 'verified');";
$result=mysqli_query($con,$query1);
}else{
//include auth.php file on all secure pages
include("auth.php");
require('db.php');
$query = "SELECT * FROM `students`;";
$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
  echo"<center><table><tr><td>ADMISSION NO</td><td>NAME</td><td>YEAR</td><td>MARK&nbsp;&nbsp;&nbsp;</td><td>DISTANCE&nbsp;&nbsp;&nbsp;&nbsp;</td><td>CATEGORY&nbsp;&nbsp;</td><td>VERIFIED</td></tr>";
  echo "<form action='' method='post'>";
  for($i=0;$i<$rows;$i++){
    echo"<tr>";
  while($r=$result->fetch_object()){
    echo"<br><br><br>";
    $admission_no=$r->admission_no;
    $name=$r->name;
    $year=$r->year;
    $mark=$r->mark;
    $distance=$r->distance;
    $category=$r->reservation_id;
    echo "<td>$admission_no</td><td>$name</td><td>$year</td><td>$mark</td><td>$distance</td><td>$category</td>";
    echo "<td><input type='checkbox' name=$admission_no value='verified'> </td></tr>";
  }
}
echo "<input type='submit' name='verified' value='SUBMIT'>";
echo"</form></table></center>";

}?>
</body>
</html>
