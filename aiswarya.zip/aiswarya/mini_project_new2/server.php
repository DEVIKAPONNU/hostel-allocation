<?php
session_start();

$admission_no="";
$errors = array();

$db = mysqli_connect('localhost', 'root', '', 'hostel_allocation');

if (isset($_POST['register'])) {
  $admission_no = mysqli_real_escape_string($db, $_POST['admission_no']);
  $name=mysqli_real_escape_string($db,$_POST['name']);
  $password1=mysqli_real_escape_string($db,$_POST['password1']);
  $password2=mysqli_real_escape_string($db,$_POST['password2']);
  $year=mysqli_real_escape_string($db,$_POST['year']);
  $mark=mysqli_real_escape_string($db,$_POST['mark']);
  $distance=mysqli_real_escape_string($db,$_POST['distance']);
  $reservation_id=mysqli_real_escape_string($db,$_POST['reservation_id']);

  if(empty($admission_no)){
    array_push($errors,"Username is required.");
  }
  if(empty($name)){
    array_push($errors,"Name is required.");
  }
  if(empty($password1)){
    array_push($errors,"Password is required.");
  }
  if(empty($year)){
    array_push($errors,"Year is required.");
  }
  if(empty($mark)){
    array_push($errors,"Mark is required.");
  }
  if(empty($distance)){
    array_push($errors,"Distance is required.");
  }
  if(empty($reservation_id)){
    array_push($errors,"Category is required.");
  }

  if ($password1 != $password2) {
	array_push($errors, "The two passwords do not match");
  }

  $user_check_query = "SELECT * FROM students WHERE admission_no='$admission_no'LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) {
      array_push($errors, "Username already exists");
  }

  if (count($errors) == 0) {
  //	$password = md5($password_1);//encrypt the password before saving in the database
  	$query = "INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`, `rank`, `hostel_id`)
        VALUES ('$admission_no', '$name', '$password', '$year', '$mark', '$distance', '$reservation_id', NULL, NULL);";
  	mysqli_query($db, $query);
    $_SESSION['admission_no']=$admission_no;
    $_SESSION['name']=$name;
    $_SESSION['year']=$year;
    $_SESSION['mark']=$mark;
    $_SESSION['distance']=$distance;
    $_SESSION['reservation_id']=$reservation_id;
  	$_SESSION['success'] = "You are now logged in";


  	header('location: student.php');
  }
}

if (isset($_POST['login'])) {
  $admission_no = mysqli_real_escape_string($db, $_POST['admission_no']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($admission_no)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	//$password = md5($password);
  	$query = "SELECT * FROM `students` WHERE `admission_no` = '$admission_no' AND `password` = '$password'";
  	$results = mysqli_query($db, $query);

  	if (mysqli_num_rows($results) == 1) {
      $_SESSION['admission_no']=$admission_no;
  	  $_SESSION['success'] = "You are now logged in";
  	  header("location: student.php?user=".$results);
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}

?>
