<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Hostel Allocation</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>

  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Admission No</label>
  	  <input type="text" name="admission_no">
  	</div>
  	<div class="input-group">
  	  <label>Name</label>
  	  <input type="Text" name="name">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password2">
  	</div>
    <div class="input-group">
  	  <label>Year</label>
      <select name="year">
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
    </select>
  	</div>
    <div class="input-group">
  	  <label>Mark</label>
  	  <input type="Text" name="mark">
  	</div>
    <div class="input-group">
      <label>Distance</label>
      <input type="Text" name="distance">
    </div>
    <div class="input-group">
      <label>Category</label>
      <select name="reservation_id">
      <option value="01">general</option>
      <option value="02">obc</option>
      <option value="03">oec</option>
      <option value="04">sc-st</option>
      <option value="05">others</option>
      </select>
    </div><br/>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="register">Register</button>
  	</div>
  	<p>
  		<a href="home.php">Sign in</a>
  	</p>
  </form>
</body>
</html>
