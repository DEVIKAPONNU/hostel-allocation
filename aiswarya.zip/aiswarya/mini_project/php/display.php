  <?php
 include 'database.php';
 if(isset($_POST['username'])){
   $username=$_POST['username'];
 }
 if(isset($_POST['password'])){
   $password=$_POST['password'];
 }
//echo $username." and ".$password;
 $sql="SELECT * FROM `students` WHERE `admission_no` LIKE '$username' AND `password` LIKE '$password'";
$result=$db->query($sql);

 while($row=$result->fetch_object()){
   $name=$row->name;
   $mark=$row->mark;
   echo "Name: $name <br>Regiter no: $mark <br> " ;
 }

 ?>
