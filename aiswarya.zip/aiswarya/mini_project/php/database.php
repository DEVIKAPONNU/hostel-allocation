<?php
$dbConnect=array(
    'server'=>'localhost',
    'user'=>'root',
    'pass'=>'',
    'name'=>'hostel_allocation'
);
$db=new mysqli(
  $dbConnect['server'],
  $dbConnect['user'],
  $dbConnect['pass'],
  $dbConnect['name']
);
?>
