<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Admin</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
 <?php echo $_SESSION['notification']; ?>
 <br/><br/>
 <a href="login.php">Log in</a>

</div>
</body>
</html>
