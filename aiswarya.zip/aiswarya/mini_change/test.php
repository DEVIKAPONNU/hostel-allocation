<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Edit</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['change'])){
  $ad=$_SESSION['admission_no'];
  if(isset($_POST['name_new'])){
  	$name_new = stripslashes($_REQUEST['name_new']);
  	$name_new = mysqli_real_escape_string($con,$name_new);
  }
  else{
    $name_new=$_SESSION['name'];
  }
  if(isset($_POST['password_new'])){
  	$password_new = stripslashes($_REQUEST['password_new']);
  	$password_new = mysqli_real_escape_string($con,$password_new);
  }
  else{
    $password_new=$_SESSION['password'];
  }
  if(isset($_POST['year_new'])){
  	$year_new = stripslashes($_REQUEST['year_new']);
  	$year_new = mysqli_real_escape_string($con,$year_new);
  }else{
    $year_new=$_SESSION['year'];
  }
  if(isset($_POST['mark_new'])){
  	$mark_new = stripslashes($_REQUEST['mark_new']);
  	$mark_new = mysqli_real_escape_string($con,$mark_new);
  }else{
    $mark_new=$_SESSION['mark'];
  }
  if(isset($_POST['distance_new'])){
    $distance_new = stripslashes($_REQUEST['distance_new']);
    $distance_new = mysqli_real_escape_string($con,$distance_new);
  }else{
    $distance_new=$_SESSION['distance'];
  }
  if(isset($_POST['reservation_id_new'])){
    $reservation_id_new = stripslashes($_REQUEST['reservation_id_new']);
    $reservation_id_new = mysqli_real_escape_string($con,$reservation_id_new);
  }else{
    $reservation_id_new=$_SESSION['reservation_id'];
  }
  $query = "UPDATE `students`
  SET `name` = '$name_new',`password` = `$password_new`,`year`='$year_new', `mark` = '$mark_new',
   `distance` = '$distance_new',`reservation_id`='$reservation_id_new'
  WHERE `students`.`admission_no` = '$ad';";
  mysqli_query($con,$query);
echo "success";
}else{
?>
<center>
<div class="form"><h2><b>EDIT PROFILE</b></h2><br/>
<!--<p>Welcome <?php echo $_SESSION['name']; ?><br/>
Mark:<?php echo $_SESSION['mark']; ?><br/>Distance:<?php echo $_SESSION['distance']; ?></p>-->
<form action="edit.php" method="post" name="change">
<table width=300 valign="center">
<tr>
  <td width="230" >Name:</td>
<td width="230"><input type="text" name="name_new" placeholder="<?php echo $_SESSION['name']; ?>"  /></td></tr>
<tr>
  <td width="230" >Password:</td>
<td width="230"><input type="text" name="password_new" placeholder="<?php echo $_SESSION['password']; ?>"  /></td></tr>
<tr>
  <td width="230">Year:</td>
<td width="230">
  <select name="year_new">
  <option value=""hidden><?php echo $_SESSION['year']; ?></option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  </select>
  </td>
</tr>
<tr>
  <td width="230">Mark:</td>
<td width="230"><input type="text" name="mark_new" placeholder="<?php echo $_SESSION['mark']; ?>"  /></td></tr>
<tr>
  <td width="230">Distance:</td>
<td width="230"><input type="text" name="distance_new" placeholder="<?php echo $_SESSION['distance']; ?>"  /></td></tr>
<tr>
  <td width="230">Category:</td>
<td width="230">
  <select name="reservation_id_new">
  <option value=""hidden><?php echo $_SESSION['reservation_id']; ?></option>
  <option value="01">1.general</option>
  <option value="02">2.obc</option>
  <option value="03">3.oec</option>
  <option value="04">4.sc-st</option>
  <option value="05">5.others</option>
  </select>
</td></tr>
</table>
<br/>
<input name="change" type="submit" value="Change" />
</form><p>
<a href="student.php">Cancel</a>
</p>
<a href="logout.php">Logout</a>
</center>
</div>
<?php } ?>
</body>
</html>
