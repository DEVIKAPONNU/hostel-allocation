<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="stylea.css" />
<link rel="stylesheet" href="main.css" />
</head>
<body class="image_login">
<br><br>
<div>

     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="download.png" id="icon" alt="User Icon" class="img" style="width:250px" height="150px"/>

<table><tr><td>
	<a href="rank.php" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					&nbsp;&nbsp;&nbsp;GENERATE RANK&nbsp;&nbsp;&nbsp;
				</b>
				</button>
				</a>
<td></tr></table><br>
<table><tr><td>
<a href="verification.php" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					&nbsp;&nbsp;&nbsp;VERIFICATION&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</b>
				</button>
				</a>
<td></tr></table><br>
<table><tr><td>
<a href="home.php" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					&nbsp;&nbsp;&nbsp;GO TO SITE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</b>
				</button>
				</a>
<td></tr></table><br>
<table><tr><td>
<a href="logout.php" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					&nbsp;&nbsp;&nbsp;LOG OUT &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</b>
				</button>
				</a>
<td></tr></table>

</div>
</body>
</html>
