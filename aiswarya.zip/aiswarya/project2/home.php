<?php
require('db.php'); ?><html>
<head><title>Home</title>
<link rel="stylesheet" href="stylea.css">
<link rel="stylesheet" href="main.css">
</head>
<body class="image-login">
	<div>
	<div>
		<font color="white">
		<br>
			<div class="sch" class="bg">
				<font color="#00009f" size="7">
				<b>
					LADIES HOSTEL
				</b>
				<BR>
				</font>
				<br>
			</div><br><br><br><br/>

	<div>
				<div>
				<font color="#0000ff" size="6">
				<b>
					GOVERNMENT ENGINEERING COLLEGE PALAKKAD
				</b>
				</font>
				</div>
			<div class="search">
				<a href="#" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					RESULT
				</b>
				</button>
				</a>
				<a href="login.php" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					LOG IN
				</b>
				</button>
				</a>
				</font>
				<a href="registration.php" class="nl">
				<button style="margin:0 0 0 0;" class="button1">
				<font color="#0000ff" size="5">
				<b>
					REGISTER
				</b>
				</font>
				</button>
				</a>
			</div></div></div>
			</div>

		</font>
<br>
<div>
<br><br><br><hr>
</div>

</p>
</body>
</html>
