<?php
$notification=$_SESSION['notification'];
echo $notification;
?>