<?php
include 'database.php';
$sql="select * from user";
$result=$db->query($sql);
?>
<p><b>RESULTS</b></p><br/>
<table border=1>
  <tr>
    <th>Reg no</th>
    <th>Name</th>
    <th>Phone no</th>
  </tr>
  <?php
  while($row=$result->fetch_object()){
    $username=htmlentities($row->name,ENT_QUOTES,"UTF-8");
    $regno=htmlentities($row->reg_no,ENT_QUOTES,"UTF-8");
    $phone=htmlentities($row->phone_no,ENT_QUOTES,"UTF-8");
?>
    <tr>
      <td><?php echo $regno?></td>
      <td><?php echo $username?></td>
      <td><?php echo $phone?></td>
    </tr>
  <?php } ?>
</table>

<p><b>INSERT NEW RECORD</b></p>
<form action="insert.php" method="post">
  <table border=1>
    <tr>
      <th>Reg no</th>
      <th>Name</th>
      <th>Phone no</th>
      <th>&nbsp</th>
    </tr>

      <tr>
        <td><input type="Text" Name="reg"/></td>
        <td><input type="Text" Name="username"/></td>
        <td><input type="Text" Name="phone"/></td>
        <td><input type="submit" value="submit"></td>
    </tr>
  </table>
</form>
