  <?php
 include 'database.php';
 if(isset($_POST['Username'])){
   $username=$_POST['Username'];
 }
 if(isset($_POST['reg'])){
   $reg=$_POST['reg'];
 }

 $sql="SELECT * FROM `user` WHERE name='$username' and reg_no='$reg'";
$result=$db->query($sql);

 while($row=$result->fetch_object()){
   $name=$row->name;
   $regno=$row->reg_no;
   $phone=$row->phone_no;
   echo "Name: $name <br>Regiter no: $regno <br>Phone no:  $phone<br> " ;
 }

 ?>
