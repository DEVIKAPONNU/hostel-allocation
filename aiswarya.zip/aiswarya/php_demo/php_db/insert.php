<?php
include 'database.php';
if(isset($_POST['username'])){
  $username=$_POST['username'];
}
if(isset($_POST['reg'])){
  $reg=$_POST['reg'];
}
if(isset($_POST['phone'])){
  $phone=$_POST['phone'];
}
$stmt=$db->prepare("INSERT INTO `user` (`name`, `reg_no`, `phone_no`) VALUES (?,?,?)");
$stmt->bind_param("sii",$username,$reg,$phone);
$stmt->execute();
$stmt->close();


header("Location: display-and-insert.php");

?>
