<?php
$dbConnect=array(
    'server'=>'localhost',
    'user'=>'root',
    'pass'=>'',
    'name'=>'test'
);
$db=new mysqli(
  $dbConnect['server'],
  $dbConnect['user'],
  $dbConnect['pass'],
  $dbConnect['name']
);

/*$sql="select * from user";
$result=$db->query($sql);
while($row=$result->fetch_object()){
  $name=$row->name;
  $regno=$row->reg_no;
  echo "$regno   $name  <br>";
}*/

 ?>
