<?php
if(isset($_POST['Username']) && isset($_POST['reg']) && isset($_POST['mark']) && isset($_POST['distance'])){
$user_name=$_POST['Username'];
$regno=$_POST['reg'];
$mark=$_POST['mark'];
$distance=$_POST['distance'];
}

?>
<form action="sample.php" method="post">
username:<input type="Text" Name="Username"/><br/><br/>
register no:<input type="Text" Name="reg"/><br/><br/>
mark:<input type="Text" Name="mark"/><br/><br/>
distance:<input type="Text" Name="distance"/><br/><br/>
<input type="submit" value="submit"><br/>
</form>

<?php
if(isset($_POST['Username']) && isset($_POST['reg']) && isset($_POST['mark']) && isset($_POST['distance'])){
echo "hi $user_name, <br/> Your register no is $regno <br/> Your distance is $distance <br/> Your mark is $mark";
}
 ?>
