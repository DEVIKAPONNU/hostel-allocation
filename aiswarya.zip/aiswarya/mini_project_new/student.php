<?php include('server.php');
  session_start();

  if (!isset($_SESSION['admission_no'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: home.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['admission_no']);
  	header("location: home.php");
  }
?>
<!doctype html>
<head><title>HOME</title></head>
<body>
  <center>
  <p><b>HOME</b></p>
  <?php if ($_SESSION['success']): ?>
    <?php echo $_SESSION['success'];
     unset($_SESSION['success']);?>

  <?php endif; ?>
  <?php if ($_SESSION['admission_no']): ?>

   <p>Welcome <?php echo $_SESSION['name']; ?> of <?php echo $_SESSION['year']; ?>th year.</p><br/><br/>
   <p><a href="student.php?logout='1'">logout</a></p>
 <?php endif; ?>

</center>
</body>

</html>
