<?php include('server.php'); ?>
<!doctype html>
<head><title>HOME</title></head>
<body>
  <center>
  <p><b>LOGIN</b></p>
  <p>
    <form action="home.php" method="post">
      <?php include('errors.php'); ?>
  Username:<input type="Text" Name="admission_no"/><br/><br/>
  Password:<input type="password" Name="password"/><br/><br/>
</p>
  <input type="submit" value="login" name="login">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="register.php"><input type="button" value="create"></a>
  <br/>
  </form>
</center>
</body>

</html>
