<?php include('server.php'); ?>
<!doctype html>
<head><title>REGISTER</title></head>
<body>
  <center>
  <p><b>CREATE</b></p>
  <p>
    <form action="register.php" method="post">

<?php include('errors.php'); ?>


  Admission No:&nbsp;&nbsp;<input type="Text" Name="admission_no" required/><br/><br/>
  Name:&nbsp;&nbsp;<input type="Text" Name="name"/><br/><br/>
  Password:&nbsp;&nbsp;<input type="password" Name="password1"/><br/><br/>
  Confirm Password:&nbsp;&nbsp;<input type="password" Name="password2"/><br/><br/>
  Year:&nbsp;&nbsp;<select name="year">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
</select>
<br/><br/>
Mark:&nbsp;&nbsp;<input type="Text" Name="mark" placeholder="cgpa or equivalent"/><br/><br/>
Distance:&nbsp;&nbsp;<input type="Text" Name="distance"/><br/><br/>
Category:&nbsp;&nbsp;<select name="reservation_id">
<option value="01">general</option>
<option value="02">obc</option>
<option value="03">oec</option>
<option value="04">sc-st</option>
<option value="05">others</option>
</select>

</p>
<button name="register" type="submit">register</button>
  <br/>
  </form>
</center>
</body>

</html>
