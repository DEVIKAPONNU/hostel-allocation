<?php
session_start();
$admission_no="";
$errors = array();
$dbConnect=array(
    'server'=>'localhost',
    'user'=>'root',
    'pass'=>'',
    'name'=>'hostel_allocation'
);
$db=new mysqli(
  $dbConnect['server'],
  $dbConnect['user'],
  $dbConnect['pass'],
  $dbConnect['name']
);
if(isset($_POST['register'])){
  $admission_no=mysql_real_escape_string($_POST['admission_no']);
  $name=mysql_real_escape_string($_POST['name']);
  $password1=mysql_real_escape_string($_POST['password1']);
  $password2=mysql_real_escape_string($_POST['password2']);
  $year=mysql_real_escape_string($_POST['year']);
  $mark=mysql_real_escape_string($_POST['mark']);
  $distance=mysql_real_escape_string($_POST['distance']);
  $reservation_id=mysql_real_escape_string($_POST['reservation_id']);
  if(empty($admission_no)){
    array_push($errors,"Username is required.");
  }
  if(empty($name)){
    array_push($errors,"Name is required.");
  }
  if(empty($password1)){
    array_push($errors,"Password is required.");
  }
  if(empty($year)){
    array_push($errors,"Year is required.");
  }
  if(empty($mark)){
    array_push($errors,"Mark is required.");
  }
  if(empty($distance)){
    array_push($errors,"Distance is required.");
  }
  if(empty($reservation_id)){
    array_push($errors,"Category is required.");
  }



  if($password1!=$password2){
    array_push($errors,"The two passwords do not match");
  }

  $user_check_query = "SELECT * FROM students WHERE admission_no='$admission_no'LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if user exists
    array_push($errors, "Username already exists");
  }


  if(count($errors)==0){
    $password=$password1;
    $sql="INSERT INTO `students` (`admission_no`, `name`, `password`, `year`, `mark`, `distance`, `reservation_id`, `rank`, `hostel_id`)
        VALUES ('$admission_no', '$name', '$password', '$year', '$mark', '$distance', '$reservation_id', NULL, NULL);";
    mysqli_query($db,$sql);
    $_SESSION['admission_no']=$admission_no;
    $_SESSION['name']=$name;
    $_SESSION['year']=$year;
    $_SESSION['mark']=$mark;
    $_SESSION['distance']=$distance;
    $_SESSION['reservation_id']=$reservation_id;

    $_SESSION['success']="You are loogged in";
    header('location:student.php');

  }
}

if(isset($_POST['login'])){
  $admission_no=mysql_real_escape_string($_POST['admission_no']);
  $password=mysql_real_escape_string($_POST['password']);
  if(empty($admission_no)){
    array_push($errors,"Username is required.");
  }
  if(empty($password)){
    array_push($errors,"Password is required.");
  }
  if(count($errors)==0){
    $query="SELECT * FROM `students` WHERE `admission_no` LIKE '$admission_no' AND `password` LIKE '$password'";
    $result=mysqli_query($db,$query);
    if(mysqli_num_rows($result)==1){
      $_SESSION['admission_no']=$admission_no;
      $_SESSION['name']=$name;
      $_SESSION['year']=$year;
      $_SESSION['mark']=$mark;
      $_SESSION['distance']=$distance;
      $_SESSION['reservation_id']=$reservation_id;
      $_SESSION['success']="You are loogged in";
      header('location:student.php');
    }else{
      array_push($errors,"Incorrect username and password");
    }

  }
}
/*if(isset($_GET['logout'])){
  session_destroy();
  unset($_SESSION['admission_no']);
  unset($_SESSION['name']);

  header('location:home.php');

}*/
 ?>
