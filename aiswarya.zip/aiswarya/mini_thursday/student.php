<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form"><h2><b>PROFILE</b></h2><br/>
<!--<p>Welcome <?php echo $_SESSION['name']; ?><br/>
Mark:<?php echo $_SESSION['mark']; ?><br/>Distance:<?php echo $_SESSION['distance']; ?></p>-->
<table width=300>
<tr>
  <td width="150">Name:</td>
  <td width="150"> <?php echo $_SESSION['name']; ?></td>
</tr>
<tr>
  <td width="150">Admission No:</td>
  <td width="150"><?php echo $_SESSION['admission_no']; ?></td>
</tr>
<tr>
  <td width="150">Year:</td>
  <td width="150"><?php echo $_SESSION['year']; ?></td>
</tr>
<tr>
  <td width="150">Mark:</td>
  <td width="150"><?php echo $_SESSION['mark']; ?></td>
</tr>
<tr>
  <td width="150">Distance:</td>
  <td width="150"><?php echo $_SESSION['distance']; ?></td>
</tr>
<tr>
  <td width="150">Category:</td>
  <td width="150"><?php echo $_SESSION['reservation_id']; ?></td>
</tr>
</table>
<p><a href="edit.php">Edit Profile</a></p>
<a href="logout.php">Logout</a>
</div>
</body>
</html>
